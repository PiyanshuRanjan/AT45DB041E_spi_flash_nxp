/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_spi.h"
#include "pin_mux.h"
#include "board.h"
#include "fsl_debug_console.h"

#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "fsl_i2c.h"
#include "fsl_power.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_SPI_MASTER          SPI7
#define EXAMPLE_SPI_MASTER_IRQ      FLEXCOMM7_IRQn
#define EXAMPLE_SPI_MASTER_CLK_SRC  kCLOCK_Flexcomm7
#define EXAMPLE_SPI_MASTER_CLK_FREQ CLOCK_GetFlexCommClkFreq(7U)
#define EXAMPLE_SPI_SSEL            1
#define EXAMPLE_SPI_SPOL            kSPI_SpolActiveAllLow



#define EXAMPLE_I2C_MASTER_BASE    (I2C1_BASE)
#define I2C_MASTER_CLOCK_FREQUENCY (12000000)
#define WAIT_TIME                  10U
#define EXAMPLE_I2C_MASTER ((I2C_Type *)EXAMPLE_I2C_MASTER_BASE)

#define I2C_MASTER_SLAVE_ADDR_7BIT 0x3EU
#define I2C_BAUDRATE               100000U
#define I2C_DATA_LENGTH            33U

#define SPI_CMD_READ_ARRAY     					0x0B
#define SPI_CMD_WRITE_BUFFER1  					0x82
#define DUMMY_DATA      						0xEE

uint8_t g_master_txBuff[I2C_DATA_LENGTH];
uint8_t g_master_rxBuff[I2C_DATA_LENGTH];



uint8_t data_buff[2];
uint8_t *send_data_ptr;




/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
#define BUFFER_SIZE (261)
static uint8_t srcBuff[BUFFER_SIZE];
static uint8_t destBuff[BUFFER_SIZE];




/*******************************************************************************
 * Code
 ******************************************************************************/

int main(void)
{

	send_data_ptr = data_buff;
    i2c_master_config_t masterConfig;
    status_t reVal        = kStatus_Fail;
    uint8_t deviceAddress = 0x7CU;

    spi_master_config_t userConfig = {0};
    uint32_t srcFreq               = 0;
    uint32_t i                     = 0;
    uint32_t err                   = 0;
    spi_transfer_t xfer            = {0};
    status_t spi_ret_status = 0xAAAAAAAA;
    uint32_t spi_buff_data_ret[30] = {0x00};
    uint32_t loop_size = 30;


    spi_half_duplex_transfer_t xferhfd = {0};
    status_t spi_hd_ret_status = 0xAAAAAAAA;

    /* set BOD VBAT level to 1.65V */
    POWER_SetBodVbatLevel(kPOWER_BodVbatLevel1650mv, kPOWER_BodHystLevel50mv, false);
    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    /* attach 12 MHz clock to FLEXCOMM8 (I2C master) */
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM1);


    /* attach 12 MHz clock to SPI3 */
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM7);

    /* reset FLEXCOMM for I2C */
    RESET_PeripheralReset(kFC1_RST_SHIFT_RSTn);

    /* reset FLEXCOMM for SPI */
    RESET_PeripheralReset(kFC7_RST_SHIFT_RSTn);

    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();

    I2C_MasterGetDefaultConfig(&masterConfig);

        /* Change the default baudrate configuration */
    masterConfig.baudRate_Bps = I2C_BAUDRATE;

        /* Initialize the I2C master peripheral */
    I2C_MasterInit(EXAMPLE_I2C_MASTER, &masterConfig, I2C_MASTER_CLOCK_FREQUENCY);



    PRINTF("\n\rMaster Start...\n\r");
    /*
     * userConfig.enableLoopback = false;
     * userConfig.enableMaster = true;
     * userConfig.polarity = kSPI_ClockPolarityActiveHigh;
     * userConfig.phase = kSPI_ClockPhaseFirstEdge;
     * userConfig.direction = kSPI_MsbFirst;
     * userConfig.baudRate_Bps = 500000U;
     */
    SPI_MasterGetDefaultConfig(&userConfig);
    srcFreq            = EXAMPLE_SPI_MASTER_CLK_FREQ;
    userConfig.sselNum = (spi_ssel_t)EXAMPLE_SPI_SSEL;
    userConfig.sselPol = (spi_spol_t)EXAMPLE_SPI_SPOL;
    SPI_MasterInit(EXAMPLE_SPI_MASTER, &userConfig, srcFreq);

    /* Init Buffer*/
    for (i = 0; i < BUFFER_SIZE; i++)
    {
        destBuff[i] = 0xAA;
        srcBuff[i] = 0xAA;
    }


    /*Start Transfer*/
    xfer.txData      = srcBuff;
    xfer.rxData      = destBuff;
    xfer.dataSize    = sizeof(destBuff);
    xfer.configFlags = kSPI_FrameAssert;

/************************************READ_ID*************************************/


    srcBuff[0] = 0x9F;

    spi_ret_status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);

/*****************************read data*****************************************/

    srcBuff[0] = SPI_CMD_READ_ARRAY;
    srcBuff[1] = 0x00;
    srcBuff[2] = 0x00;
    srcBuff[3] = 0x00;
    srcBuff[4] = DUMMY_DATA;
    spi_ret_status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);

/******************************write data**************************************/

    srcBuff[0] = SPI_CMD_WRITE_BUFFER1;
    srcBuff[1] = 0x00;
    srcBuff[2] = 0x00;
    srcBuff[3] = 0x00;
    for (i = 4; i < BUFFER_SIZE; i++)
    {
        srcBuff[i] = 0x66;
    }
    spi_ret_status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);

/***************************read data*******************************************/

    srcBuff[0] = SPI_CMD_READ_ARRAY;
    srcBuff[1] = 0x00;
    srcBuff[2] = 0x00;
    srcBuff[3] = 0x00;
    srcBuff[4] = DUMMY_DATA;
    spi_ret_status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);
}
